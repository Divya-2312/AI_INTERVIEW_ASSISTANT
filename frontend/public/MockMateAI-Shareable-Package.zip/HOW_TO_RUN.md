# MockMate AI - Quick Start Guide

Welcome to **MockMate AI**, a full-stack AI interview preparation platform.

## Architecture
- **Frontend**: React + Vite (Port 3000)
- **Backend**: Node.js Express + MongoDB (Port 5000)
- **AI Microservice**: FastAPI + Ollama (Port 8000)

## Getting Started

### 1. AI Service
`ash
cd mockmate/ai-service
python -m venv .venv
# On Windows: .\.venv\Scripts\activate  |  On Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn app.main:app --port 8000
`

### 2. Backend
`ash
cd mockmate/backend
npm install
npm run dev
`

### 3. Frontend
`ash
cd mockmate/frontend
npm install
npm run dev
`
Open **http://localhost:3000** in your browser.

### 4. Ollama Model
Ensure Ollama is running (ollama serve). Pull a model:
`ash
ollama pull llama3.2:3b
`
