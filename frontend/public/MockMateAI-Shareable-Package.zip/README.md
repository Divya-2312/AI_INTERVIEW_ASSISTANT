# MockMate AI

MockMate AI is a full-stack interview preparation system with a React frontend, an Express backend, a FastAPI AI service, a BERT-based semantic retrieval layer, and an Ollama-backed LLaMA inference path. The repository already includes a bundled dataset pack and a training toolkit for LoRA/QLoRA fine-tuning.

## Architecture

```mermaid
flowchart LR
    FE[React + Vite frontend] --> BE[Express backend]
    BE --> AI[FastAPI AI service]
    AI --> RAG[BERT semantic retrieval + knowledge base]
    AI --> OLLAMA[Ollama / GGUF model]
    OLLAMA --> FT[Fine-tuned LLaMA adapter]
    TRAIN[training pipeline] --> ADAPTER[LoRA adapter]
    ADAPTER --> GGUF[GGUF export]
    GGUF --> OLLAMA
```

## Repository layout

- `mockmate/frontend` — React application
- `mockmate/backend` — Node/Express REST API
- `mockmate/ai-service` — FastAPI AI service and provider abstraction
- `mockmate/training` — dataset prep, conversion, and fine-tuning scripts
- `mockmate/ai-service/knowledge` — domain knowledge used by the retrieval layer
- `mockmate/training/data/raw` — bundled source datasets

## Dataset structure

The bundled raw data lives under `mockmate/training/data/raw` and contains six JSONL files:

- `java_theory_100.jsonl`
- `java_output_prediction_100.jsonl`
- `java_coding_100.jsonl`
- `dbms_theory_100.jsonl`
- `sql_coding_100.jsonl`
- `hr_questions_100.jsonl`

Each record is a JSON object with a task-specific schema. The conversion script accepts the repo's actual schema and produces canonical instruction-style records for SFT. Source datasets remain unchanged.

## Dataset preparation

From `mockmate/training`:

```powershell
python prepare_mockmate_datasets.py --input-dir data/raw --output data/processed/canonical.jsonl --summary-path data/processed/canonical_summary.json
python prepare_dataset.py --input data/processed/canonical.jsonl --output-dir data/processed/splits --summary-path data/processed/splits/summary.json --seed 42
```

This creates:

- `data/processed/canonical.jsonl`
- `data/processed/splits/train.jsonl`
- `data/processed/splits/validation.jsonl`
- `data/processed/splits/test.jsonl`
- JSON validation summaries for counts, rejected records, duplicates, and subject distribution.

## Training in Google Colab

This project assumes a GPU runtime such as Google Colab for LoRA/QLoRA fine-tuning. The training script is designed for a notebook environment rather than CPU-only local tuning.

1. Upload `train.jsonl` and `validation.jsonl` from `mockmate/training/data/processed/splits` to Colab.
2. Upload `mockmate/training/train_qlora.py`.
3. Run:

```python
!pip install -U unsloth datasets trl peft transformers accelerate bitsandbytes
!python /content/train_qlora.py \
  --train /content/data/train.jsonl \
  --validation /content/data/validation.jsonl \
  --output /content/mockmate-llama-adapter \
  --gguf-output /content/mockmate-llama-gguf \
  --max-steps 100
```

A 100-step run is a smoke test only. It is not evidence of production readiness. Use the held-out test split for evaluation after fine-tuning.

## GGUF export and Ollama

After training, export the adapter and convert it to a GGUF model. The repository's notebook-friendly workflow is:

```bash
# In the Colab environment
!ls /content/mockmate-llama-gguf
```

Then create a local Ollama Modelfile using the real exported `.gguf` filename:

```powershell
cd mockmate\ai-service\models\mockmate-llama-gguf
@'
FROM ./mockmate-llama-q4_k_m.gguf
PARAMETER temperature 0.2
PARAMETER num_ctx 4096
'@ | Set-Content -Encoding ascii Modelfile

ollama create mockmate-llama-ft -f Modelfile
ollama run mockmate-llama-ft "Generate a Java interview question about type erasure as JSON."
```

## Environment variables

Copy the `.env.example` files in each service folder and fill in local values without secrets:

- `mockmate/ai-service/.env.example`
- `mockmate/backend/.env.example`
- `mockmate/frontend/.env.example`

Key AI settings:

```env
MODEL_NAME=mockmate-llama-ft
MODEL_ENDPOINT=http://localhost:11434/api/generate
STRICT_AI_MODE=false
FOLLOW_UP_PERCENTAGE=25
MAX_FOLLOW_UPS=3
```

## Startup commands

### Frontend

```powershell
cd mockmate/frontend
npm install
npm run dev
```

### Backend

```powershell
cd mockmate/backend
npm install
npm run dev
```

### AI service

```powershell
cd mockmate/ai-service
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Check health:

```bash
curl http://localhost:8000/health
```

## Testing

### AI service

```powershell
cd mockmate/ai-service
python -m unittest discover -s tests -v
```

### Dataset pipeline

```powershell
cd mockmate/training
python -m unittest tests/test_dataset_pipeline.py -v
```

### Frontend build

```powershell
cd mockmate/frontend
npm run build
```

## Hardware and limitations

- Fine-tuning should be done in Google Colab or another GPU-backed environment.
- Local CPU-only inference can be slow and is not suitable for proof-of-training.
- The bundled source data supports generation and reference-answer formats, but it does not contain verified student-evaluation labels. A human-reviewed evaluation dataset is still required for reliable answer scoring and follow-up supervision.
- A GGUF export path is supported, but model conversion and Ollama registration must be handled outside of the repo for large artifacts.

## Known limitations

- The bundled dataset is a strong seed set, not a complete supervised dataset for grading and adaptive follow-up fine-tuning.
- Evaluation is still grounded in retrieval, rubric logic, and exact programmatic checks for coding problems.
- Model output must be validated and not trusted blindly.

## Evaluation methodology

The app keeps a rubric-based technical/grading flow and uses BERT embeddings as a supporting signal rather than as the sole source of truth. Coding problems are executed against test cases when possible and the result is recorded instead of silently trusting an LLM verdict.

The training pipeline is intentionally transparent about duplicate counts, malformed rows, and subject distribution so that dataset quality is visible before model training begins.

## Deterministic Coding Evaluation & Java Setup

MockMate AI executes candidate Java code (`javac` + `java`) and SQL queries (in-memory SQLite) deterministically in sandboxed subprocesses with a 5-second per-test-case timeout.

### Installing the JDK on Windows

To enable deterministic Java code execution:

1. **Download OpenJDK**:
   - Download Eclipse Adoptium Temurin (JDK 17 or 21 LTS) from [https://adoptium.net/](https://adoptium.net/) or install via `winget`:
     ```powershell
     winget install EclipseAdoptium.Temurin.21.JDK
     ```
2. **Verify Environment Variables**:
   - Ensure `JAVA_HOME` points to your JDK directory (e.g. `C:\Program Files\Eclipse Adoptium\jdk-21.0.x-hotspot\`).
   - Ensure `%JAVA_HOME%\bin` is added to your system `PATH`.
3. **Verify Installation**:
   - Open a fresh PowerShell terminal and run:
     ```powershell
     javac -version
     java -version
     ```
   - Both commands should output the installed Java version (e.g., `javac 21.0.x`).
4. **Health Check Verification**:
   - Start the AI service and verify that the Java runtime is detected:
     ```bash
     curl http://localhost:8000/health
     ```
     Response includes: `"javaRuntime": true`.
   - If no JDK is detected, the AI service gracefully falls back to deterministic LLM evaluation (`"judgeMode": "llm-fallback"`).

### Security and Sandbox Notice

> [!CAUTION]
> **Local Demo Environment**: The subprocess-based Java code executor runs locally with a 5.0-second execution timeout, a temporary working directory cleaned up after execution, and output size caps (64 KB). However, for any public or multi-tenant production deployment, code execution **must be containerized** (e.g., using Docker, gVisor, or isolated ephemeral micro-VMs such as AWS Firecracker) with non-root privileges, strict memory/CPU cgroups, and disabled network access to prevent unauthorized host interaction.
