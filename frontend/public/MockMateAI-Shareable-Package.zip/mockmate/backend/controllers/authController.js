import { createHash, randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';

const PASSWORD_RESET_TTL_MS = 15 * 60 * 1000;

const hashResetToken = (token) => createHash('sha256').update(token).digest('hex');

const generateToken = (id) => {
  return jwt.sign(
    { id },
    process.env.JWT_SECRET || 'mockmate_ai_jwt_secret_key_2026_super_secure',
    { expiresIn: '30d' }
  );
};

// @desc    Register a new student
// @route   POST /api/auth/register
// @access  Public
export const registerUser = async (req, res, next) => {
  try {
    const { name, email, password, degree, university, targetRole } = req.body;

    if (!name || !email || !password) {
      res.status(400);
      throw new Error('Please provide name, email, and password');
    }

    if (password.length < 6) {
      res.status(400);
      throw new Error('Password must be at least 6 characters');
    }

    const userExists = await User.findOne({ email: email.toLowerCase() });
    if (userExists) {
      res.status(409);
      throw new Error('User with this email already exists');
    }

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password,
      degree: degree || 'B.Tech Computer Science',
      university: university || 'Anna University',
      targetRole: targetRole || 'Software Development Engineer (SDE)',
    });

    if (user) {
      res.status(201).json({
        success: true,
        message: 'Registration successful',
        token: generateToken(user._id),
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          degree: user.degree,
          university: user.university,
          targetRole: user.targetRole,
        },
      });
    } else {
      res.status(400);
      throw new Error('Invalid user data provided');
    }
  } catch (error) {
    next(error);
  }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
export const loginUser = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400);
      throw new Error('Please provide email and password');
    }

    const user = await User.findOne({ email: email.toLowerCase() });

    if (user && (await user.matchPassword(password))) {
      res.json({
        success: true,
        message: 'Login successful',
        token: generateToken(user._id),
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          degree: user.degree,
          university: user.university,
          targetRole: user.targetRole,
        },
      });
    } else {
      res.status(401);
      throw new Error('Invalid email or password');
    }
  } catch (error) {
    next(error);
  }
};

// @desc    Request a password reset
// @route   POST /api/auth/forgot-password
// @access  Public
export const forgotPassword = async (req, res, next) => {
  try {
    const email = typeof req.body.email === 'string'
      ? req.body.email.trim().toLowerCase()
      : '';
    const resetToken = randomBytes(32).toString('hex');

    if (email) {
      const user = await User.findOne({ email }).select('_id');
      if (user) {
        await User.updateOne(
          { _id: user._id },
          {
            $set: {
              passwordResetTokenHash: hashResetToken(resetToken),
              passwordResetExpiresAt: new Date(Date.now() + PASSWORD_RESET_TTL_MS),
            },
          }
        );
      }
    }

    const response = {
      success: true,
      message: 'If an account with that email exists, password reset instructions are available.',
    };

    // Local development has no email provider; return an opaque token for the UI to link.
    // Generate it for unknown addresses too, so response shape does not reveal account existence.
    if (process.env.NODE_ENV !== 'production') {
      response.developmentResetToken = resetToken;
    }

    res.json(response);
  } catch (error) {
    next(error);
  }
};

// @desc    Reset a password using a single-use token
// @route   POST /api/auth/reset-password
// @access  Public
export const resetPassword = async (req, res, next) => {
  try {
    const { token, password, confirmPassword } = req.body;

    if (!token || !password || !confirmPassword) {
      res.status(400);
      throw new Error('Please provide the reset token and both password fields');
    }

    if (password.length < 6) {
      res.status(400);
      throw new Error('Password must be at least 6 characters');
    }

    if (password !== confirmPassword) {
      res.status(400);
      throw new Error('Passwords do not match');
    }

    const resetTokenHash = hashResetToken(token);
    const matchingUser = await User.findOne({
      passwordResetTokenHash: resetTokenHash,
      passwordResetExpiresAt: { $gt: new Date() },
    }).select('_id');

    if (!matchingUser) {
      res.status(400);
      throw new Error('Password reset link is invalid or expired. Request a new one.');
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);
    const updatedUser = await User.findOneAndUpdate(
      {
        _id: matchingUser._id,
        passwordResetTokenHash: resetTokenHash,
        passwordResetExpiresAt: { $gt: new Date() },
      },
      {
        $set: {
          password: passwordHash,
          passwordResetTokenHash: null,
          passwordResetExpiresAt: null,
        },
      },
      { new: true, runValidators: true }
    );

    if (!updatedUser) {
      res.status(400);
      throw new Error('Password reset link is invalid or expired. Request a new one.');
    }

    res.json({ success: true, message: 'Password reset successfully. Please log in.' });
  } catch (error) {
    next(error);
  }
};

// @desc    Get current user profile
// @route   GET /api/auth/me
// @access  Private
export const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    if (!user) {
      res.status(404);
      throw new Error('User not found');
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        degree: user.degree,
        university: user.university,
        targetRole: user.targetRole,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    next(error);
  }
};
