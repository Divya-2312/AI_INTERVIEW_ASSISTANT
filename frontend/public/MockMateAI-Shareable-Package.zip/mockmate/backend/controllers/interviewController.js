import { interviewEngine } from '../services/interviewEngine.js';
import { aiService } from '../services/aiService.js';
import { Interview } from '../models/Interview.js';
import { Answer } from '../models/Answer.js';

function sanitizeQuestionForClient(q) {
  if (!q) return q;
  const copy = typeof q.toObject === 'function' ? q.toObject() : { ...q };
  delete copy.referenceSolution;
  delete copy.solution;
  delete copy._referenceQuery;
  if (copy.questionFormat === 'output_prediction') {
    delete copy.expectedOutput;
  }
  return copy;
}

export const createInterview = async (req, res, next) => {
  try {
    const { type, subject, difficulty, questionFormat } = req.body;
    const result = await interviewEngine.startSession(req.user._id, type, subject, difficulty, questionFormat);

    const safeFirstQuestion = sanitizeQuestionForClient(result.question);
    const safeInterview = result.interview.toObject();
    if (safeInterview.currentQuestionData) {
      safeInterview.currentQuestionData = sanitizeQuestionForClient(safeInterview.currentQuestionData);
    }

    res.status(201).json({
      success: true,
      message: 'Interview session started',
      interview: safeInterview,
      firstQuestion: safeFirstQuestion,
    });
  } catch (error) {
    next(error);
  }
};

export const getUserInterviews = async (req, res, next) => {
  try {
    const interviews = await Interview.find({ userId: req.user._id }).sort({ createdAt: -1 });
    res.json({ success: true, count: interviews.length, interviews });
  } catch (error) {
    next(error);
  }
};

export const getInterviewById = async (req, res, next) => {
  try {
    const interview = await Interview.findById(req.params.id);
    if (!interview) {
      res.status(404);
      throw new Error('Interview not found');
    }
    if (interview.userId.toString() !== req.user._id.toString()) {
      res.status(403);
      throw new Error('Access denied');
    }
    const answers = await Answer.find({ interviewId: interview._id });
    const interviewObj = interview.toObject();
    if (interviewObj.currentQuestionData && interview.status === 'in-progress') {
      interviewObj.currentQuestionData = sanitizeQuestionForClient(interviewObj.currentQuestionData);
    }
    res.json({ success: true, interview: { ...interviewObj, answers } });
  } catch (error) {
    next(error);
  }
};

export const submitAnswer = async (req, res, next) => {
  try {
    const {
      questionId, questionText, answerText, expectedConcepts, questionFormat,
      expectedOutput, explanation, testCases, language, codeSnippet, title,
      hrDeliveryMetrics, schema, sampleData, referenceSolution
    } = req.body;

    if (!answerText || answerText.trim().length === 0) {
      res.status(400);
      throw new Error('Answer text cannot be empty');
    }

    const result = await interviewEngine.processAnswer(
      req.params.id,
      req.user._id,
      questionId,
      questionText,
      answerText,
      expectedConcepts,
      questionFormat,
      expectedOutput,
      explanation,
      testCases,
      language,
      codeSnippet,
      title,
      hrDeliveryMetrics,
      schema,
      sampleData,
      referenceSolution
    );

    res.status(200).json({
      success: true,
      evaluation: result.evaluation,
      nextQuestion: sanitizeQuestionForClient(result.nextQuestion),
      isFollowUp: result.isFollowUp,
      interviewStatus: result.interviewStatus,
    });
  } catch (error) {
    next(error);
  }
};

export const completeInterview = async (req, res, next) => {
  try {
    const interview = await Interview.findById(req.params.id);
    if (!interview) {
      res.status(404);
      throw new Error('Interview not found');
    }
    if (interview.userId.toString() !== req.user._id.toString()) {
      res.status(403);
      throw new Error('Unauthorized');
    }

    interview.status = 'completed';
    interview.completedAt = new Date();
    await interview.save();

    res.json({ success: true, message: 'Interview completed', interview });
  } catch (error) {
    next(error);
  }
};

export const getQuestionSolution = async (req, res, next) => {
  try {
    const interview = await Interview.findById(req.params.id);
    if (!interview) {
      return res.status(404).json({ success: false, error: 'Interview not found' });
    }
    if (interview.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, error: 'Access denied' });
    }

    const type = (interview.type || '').toLowerCase();
    const qData = interview.currentQuestionData || {};
    const format = (qData.questionFormat || interview.questionFormat || '').toLowerCase();
    const subject = (interview.subject || '').toLowerCase();

    // Return 400 for HR, Java theory, and DBMS theory interviews
    if (type === 'hr' || format === 'theory') {
      return res.status(400).json({
        success: false,
        error: 'Solutions are not available for theory or HR questions',
      });
    }

    const isSupported = format === 'coding' || format === 'output_prediction';
    if (!isSupported) {
      return res.status(400).json({
        success: false,
        error: 'Solutions are not available for this question format',
      });
    }

    const language = (qData.language || (subject === 'dbms' ? 'sql' : 'java')).toLowerCase();

    let solution = null;
    if (format === 'coding') {
      solution = qData.referenceSolution || qData.solution || null;
    } else if (format === 'output_prediction') {
      solution = qData.expectedOutput || qData.correctAnswer || null;
    }

    // Backward compatibility: If current question in memory has no solution, fallback to latest answer if available
    if (!solution && (!interview.currentQuestionData || interview.status === 'completed')) {
      const lastAnswer = await Answer.findOne({ interviewId: interview._id }).sort({ createdAt: -1 });
      if (lastAnswer) {
        if (format === 'coding') {
          solution = lastAnswer.referenceSolution || lastAnswer.correctedCode || null;
        } else if (format === 'output_prediction') {
          solution = lastAnswer.expectedOutput || null;
        }
      }
    }

    return res.status(200).json({
      success: true,
      format,
      language,
      solution: solution || null,
      message: solution ? undefined : 'Solution not available for this question',
    });
  } catch (error) {
    next(error);
  }
};
