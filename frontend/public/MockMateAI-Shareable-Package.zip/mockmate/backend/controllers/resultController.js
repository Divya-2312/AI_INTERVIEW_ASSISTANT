import { Interview } from '../models/Interview.js';
import { Answer } from '../models/Answer.js';
import { Result } from '../models/Result.js';

// @desc    Get result report for an interview session
// @route   GET /api/results/:interviewId
// @access  Private
export const getInterviewResult = async (req, res, next) => {
  try {
    const { interviewId } = req.params;

    const interview = await Interview.findById(interviewId);

    if (!interview) {
      res.status(404);
      throw new Error('Interview record not found');
    }

    // Ownership check
    if (interview.userId.toString() !== req.user._id.toString()) {
      res.status(403);
      throw new Error('Access denied: Unauthorized to view this result');
    }

    const answers = await Answer.find({ interviewId: interview._id });
    let result = await Result.findOne({ interviewId: interview._id });

    if (!result) {
      // Return structured response indicating AI evaluation pending
      result = {
        interviewId: interview._id,
        userId: req.user._id,
        overallScore: interview.score || null,
        strengths: [
          'Completed response recorded for analysis.',
          'Active engagement during mock session.',
        ],
        weaknesses: [
          'Detailed conceptual breakdown pending AI evaluation module integration.',
        ],
        recommendations: [
          'Practice additional subject topics while AI module integration is finalized.',
        ],
        questionsAttempted: answers.length,
        totalQuestions: interview.questionsCount || 5,
        evaluationStatus: 'pending_ai_module',
      };
    }

    res.json({
      success: true,
      interview,
      answers,
      result,
    });
  } catch (error) {
    next(error);
  }
};
