import json, requests

rows = [json.loads(l) for l in open("training/data/processed/splits/test.jsonl", encoding="utf-8")]
seen = set()
for r in rows:
    t = r["task"]
    if t in seen:
        continue
    seen.add(t)
    print("=" * 70)
    print("TASK:", t)
    try:
        print("EXPECTED KEYS:", list(json.loads(r["messages"][2]["content"]).keys()))
    except Exception as e:
        print("expected answer not JSON:", e)
    for m in ["mockmate-llama-ft", "llama3.2:3b"]:
        res = requests.post(
            "http://localhost:11434/api/chat",
            json={"model": m, "messages": r["messages"][:2], "stream": False,
                  "options": {"temperature": 0.2}},
            timeout=600,
        ).json()
        print("--", m)
        print(res["message"]["content"][:700])