#!/usr/bin/env python3
"""
Evaluate any Ollama model on the test dataset split (training/data/processed/splits/test.jsonl).
Measures:
- Sample count (n)
- JSON validity rate
- Required dataset keys rate per task
- Band accuracy (% predicted score inside labeled band for evaluate_answer)
- Monotonic ordering accuracy (% where reference > partial > wrong)
- Side-by-side comparison between fine-tuned and base models
Writes results to training/metadata/eval_<model_slug>_<timestamp>.json
"""

import sys
import os
import json
import argparse
import time
import random
import statistics
import requests
from pathlib import Path
from datetime import datetime
from collections import defaultdict

ROOT_DIR = Path(__file__).resolve().parent.parent
TEST_FILE = ROOT_DIR / "training" / "data" / "processed" / "splits" / "test.jsonl"
METADATA_DIR = ROOT_DIR / "training" / "metadata"

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")

# Training schema required keys per task
TRAINING_SCHEMA_KEYS = {
    "evaluate_answer": [
        "score", "conceptCoverage", "correctness", "relevance", "communication",
        "isIrrelevant", "feedback", "strengths", "weaknesses", "coveredConcepts",
        "missingConcepts", "improvementSuggestion", "scoreReason"
    ],
    "generate_question": [
        "question", "difficulty", "questionFormat"
    ],
    "generate_coding_problem": [
        "title", "description", "constraints", "starterCode", "testCases", "difficulty", "questionFormat"
    ],
    "generate_followup": [
        "followupQuestion"
    ]
}

SCORE_BANDS = {
    "reference": (70, 100),
    "partial": (30, 70),
    "wrong": (0, 30),
}


def check_ollama_model(model_name):
    try:
        res = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        if res.status_code == 200:
            models = [m.get("name") for m in res.json().get("models", [])]
            if model_name in models or any(m.startswith(model_name) or model_name.startswith(m.split(":")[0]) for m in models):
                return True
            print(f"[WARN] Model '{model_name}' is not present in local Ollama storage ({models}).")
            return False
    except Exception as exc:
        print(f"[ERROR] Could not connect to Ollama at {OLLAMA_URL}: {exc}")
        return False
    return False


def query_ollama(model_name, system_prompt, user_prompt, temperature=0.2, seed=None):
    options = {"temperature": temperature}
    if seed is not None:
        options["seed"] = seed

    payload = {
        "model": model_name,
        "system": system_prompt,
        "prompt": user_prompt,
        "stream": False,
        "options": options
    }
    try:
        res = requests.post(f"{OLLAMA_URL}/api/generate", json=payload, timeout=60)
        if res.status_code == 200:
            return res.json().get("response", "").strip()
    except Exception:
        pass
    return ""


def parse_json_response(response_text):
    if not response_text:
        return None
    cleaned = response_text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1:
        try:
            parsed = json.loads(cleaned[start:end+1])
            if isinstance(parsed, dict) and "evaluation" in parsed and isinstance(parsed["evaluation"], dict):
                merged = dict(parsed["evaluation"])
                for k, v in parsed.items():
                    if k != "evaluation" and k not in merged:
                        merged[k] = v
                return merged
            return parsed
        except Exception:
            pass
    return None


def extract_score(response_text):
    data = parse_json_response(response_text)
    if not data or not isinstance(data, dict):
        return None
    if "score" in data and data["score"] is not None:
        try:
            return float(data["score"])
        except (ValueError, TypeError):
            pass
    if "relevance" in data or "correctness" in data:
        try:
            rel = float(data.get("relevance", 0.5))
            corr = float(data.get("correctness", 0.0))
            cov = float(data.get("conceptCoverage", corr) if not isinstance(data.get("conceptCoverage"), list) else corr)
            comm = float(data.get("communication", 0.75))
            return float(round((rel * 0.25 + corr * 0.30 + cov * 0.30 + comm * 0.15) * 100))
        except (ValueError, TypeError):
            pass
    return None


def evaluate_model_on_rows(model_name, test_rows, temperature=0.2, seed=None):
    print(f"\nEvaluating model '{model_name}' (temp={temperature}, seed={seed}) on {len(test_rows)} test examples...")

    task_stats = {}
    total_samples = 0
    total_json_valid = 0
    total_keys_valid = 0
    per_key_failures = defaultdict(lambda: defaultdict(int))

    eval_band_total = 0
    eval_band_correct = 0
    eval_question_variants = defaultdict(dict)
    no_score_rows = []

    for idx, row in enumerate(test_rows, 1):
        msgs = row.get("messages", [])
        system_msg = next((m["content"] for m in msgs if m.get("role") == "system"), "")
        user_msg = next((m["content"] for m in msgs if m.get("role") == "user"), "")
        task = row.get("task", "unknown")

        if task not in task_stats:
            task_stats[task] = {
                "count": 0,
                "json_valid_count": 0,
                "required_keys_valid_count": 0,
            }

        task_stats[task]["count"] += 1
        total_samples += 1

        response_text = query_ollama(model_name, system_msg, user_msg, temperature=temperature, seed=seed)
        parsed_json = parse_json_response(response_text)

        is_valid_json = parsed_json is not None
        keys_valid = False

        if is_valid_json:
            task_stats[task]["json_valid_count"] += 1
            total_json_valid += 1

            required_keys = TRAINING_SCHEMA_KEYS.get(task, [])
            missing_for_row = []
            for k in required_keys:
                if k not in parsed_json:
                    missing_for_row.append(k)
                    per_key_failures[task][k] += 1

            if not missing_for_row:
                keys_valid = True
                task_stats[task]["required_keys_valid_count"] += 1
                total_keys_valid += 1

        if task == "evaluate_answer":
            predicted_score = extract_score(response_text)
            if predicted_score is None:
                no_score_rows.append((idx, response_text[:120].replace("\n", " ")))

            case_type = row.get("case_type")
            if not case_type:
                target_score = None
                if len(msgs) >= 2 and msgs[-1].get("role") == "assistant":
                    try:
                        target_data = parse_json_response(msgs[-1]["content"])
                        if target_data and "score" in target_data:
                            target_score = float(target_data["score"])
                    except Exception:
                        pass
                if target_score is not None:
                    if target_score >= 70:
                        case_type = "reference"
                    elif target_score >= 30:
                        case_type = "partial"
                    else:
                        case_type = "wrong"
                else:
                    case_type = "reference"

            base_q_id = None
            try:
                if "INPUT:\n" in user_msg:
                    json_str = user_msg.split("INPUT:\n", 1)[1].rsplit("\n\nReturn", 1)[0].strip()
                    input_data = json.loads(json_str)
                    base_q_id = input_data.get("question")
            except Exception:
                pass
            if not base_q_id:
                source_id = row.get("source_id", "")
                base_q_id = source_id.split("_eval_")[0] if "_eval_" in source_id else source_id

            if predicted_score is not None:
                band_min, band_max = SCORE_BANDS.get(case_type, (0, 100))
                eval_band_total += 1
                if band_min <= predicted_score <= band_max:
                    eval_band_correct += 1
                if base_q_id:
                    eval_question_variants[base_q_id][case_type] = predicted_score

        if idx % 25 == 0 or idx == len(test_rows):
            print(f"  Progress: {idx}/{len(test_rows)} | Valid JSON: {total_json_valid}/{idx} ({total_json_valid/idx*100:.1f}%) | Exact Schema Keys: {total_keys_valid}/{idx} ({total_keys_valid/idx*100:.1f}%)")

    ordering_total = 0
    ordering_correct = 0
    for q_id, variants in eval_question_variants.items():
        if "reference" in variants and "partial" in variants and "wrong" in variants:
            ordering_total += 1
            if variants["reference"] > variants["partial"] > variants["wrong"]:
                ordering_correct += 1

    band_accuracy_pct = round((eval_band_correct / eval_band_total * 100) if eval_band_total > 0 else 0.0, 2)
    ordering_accuracy_pct = round((ordering_correct / ordering_total * 100) if ordering_total > 0 else 0.0, 2)

    per_task_results = {}
    for t_name, stats in task_stats.items():
        cnt = stats["count"]
        jv = stats["json_valid_count"]
        kv = stats["required_keys_valid_count"]
        per_task_results[t_name] = {
            "count": cnt,
            "json_valid_count": jv,
            "json_valid_rate": round(jv / cnt if cnt > 0 else 0.0, 4),
            "exact_keys_valid_count": kv,
            "exact_keys_valid_rate": round(kv / cnt if cnt > 0 else 0.0, 4),
            "key_failures": dict(per_key_failures[t_name])
        }

    overall_results = {
        "model": model_name,
        "timestamp": datetime.now().isoformat(),
        "total_samples": total_samples,
        "json_valid_count": total_json_valid,
        "json_valid_rate": round(total_json_valid / total_samples if total_samples > 0 else 0.0, 4),
        "exact_keys_valid_count": total_keys_valid,
        "exact_keys_valid_rate": round(total_keys_valid / total_samples if total_samples > 0 else 0.0, 4),
        "no_score_count": len(no_score_rows),
        "evaluate_answer_analysis": {
            "eval_samples_n": eval_band_total,
            "band_accuracy_pct": band_accuracy_pct,
            "ordering_questions_n": ordering_total,
            "ordering_accuracy_pct": ordering_accuracy_pct,
        },
        "per_task": per_task_results,
    }

    print("\n=======================================================")
    print(f" EVALUATION COMPLETE: {model_name}")
    print("=======================================================")
    print(f"Total Samples (n)       : {total_samples}")
    print(f"JSON Validity Rate      : {overall_results['json_valid_rate']*100:.1f}%")
    print(f"Exact Schema Keys Rate  : {overall_results['exact_keys_valid_rate']*100:.1f}%")
    print("Per-Task Key Failure Breakdown:")
    for t_name, t_res in per_task_results.items():
        print(f"  Task '{t_name}' (n={t_res['count']}): Exact Schema Pass={t_res['exact_keys_valid_count']}/{t_res['count']} ({t_res['exact_keys_valid_rate']*100:.1f}%)")
        if t_res["key_failures"]:
            print("    Missing keys breakdown:")
            for k_name, f_cnt in t_res["key_failures"].items():
                print(f"      - Key '{k_name}': missing in {f_cnt}/{t_res['count']} outputs ({f_cnt/t_res['count']*100:.1f}%)")
        else:
            print("    Missing keys breakdown: None (100% exact match)")
    print(f"Eval Band Accuracy (%)  : {band_accuracy_pct}% (n={eval_band_total})")
    print(f"Eval Monotonic Order (%) : {ordering_accuracy_pct}% (n={ordering_total})")
    print("=======================================================\n")

    return overall_results


def print_side_by_side_multi(results_list):
    print("\n====================================================================================================")
    print(" SIDE-BY-SIDE EVALUATION COMPARISON REPORT (EVALUATED ON IDENTICAL STRATIFIED TEST ROWS)")
    print("====================================================================================================")
    headers = [r["model"] for r in results_list]
    hdr_line = f"{'Metric':<35} | " + " | ".join(f"{h:<22}" for h in headers)
    print(hdr_line)
    print("-" * len(hdr_line))

    samples_line = f"{'Total Samples (n)':<35} | " + " | ".join(f"{str(r['total_samples']):<22}" for r in results_list)
    print(samples_line)

    json_line = f"{'JSON Validity Rate':<35} | " + " | ".join(f"{str(round(r['json_valid_rate']*100, 1)) + '%':<22}" for r in results_list)
    print(json_line)

    req_line = f"{'Exact Schema Keys Rate':<35} | " + " | ".join(f"{str(round(r['exact_keys_valid_rate']*100, 1)) + '%':<22}" for r in results_list)
    print(req_line)

    band_strs = []
    for r in results_list:
        ev = r.get("evaluate_answer_analysis", {})
        val = f"{ev.get('band_accuracy_pct', 0)}% (n={ev.get('eval_samples_n', 0)})"
        band_strs.append(f"{val:<22}")
    print(f"{'Eval Band Accuracy (n)':<35} | " + " | ".join(band_strs))

    ord_strs = []
    for r in results_list:
        ev = r.get("evaluate_answer_analysis", {})
        val = f"{ev.get('ordering_accuracy_pct', 0)}% (n={ev.get('ordering_questions_n', 0)})"
        ord_strs.append(f"{val:<22}")
    print(f"{'Eval Monotonic Order (ref>part>wrong)':<35} | " + " | ".join(ord_strs))
    print("====================================================================================================\n")


def stratified_sample(all_rows, limit=100, seed=42):
    by_task = defaultdict(list)
    for r in all_rows:
        by_task[r.get("task", "unknown")].append(r)

    rng = random.Random(seed)
    sampled = []
    total_rows = len(all_rows)

    print(f"Stratifying sample of {limit} rows across {len(by_task)} tasks (total rows={total_rows}, seed={seed}):")
    for task_name, rows in by_task.items():
        shuffled = list(rows)
        rng.shuffle(shuffled)
        target_cnt = max(1, round(len(rows) / total_rows * limit))
        task_sampled = shuffled[:target_cnt]
        sampled.extend(task_sampled)
        print(f"  - Task '{task_name:<25}': total={len(rows):3d} -> sampled={len(task_sampled):3d}")

    rng.shuffle(sampled)
    return sampled[:limit]


def main():
    parser = argparse.ArgumentParser(description="Evaluate Ollama models on test split")
    parser.add_argument("--model", required=True, help="Primary Ollama model name (e.g., mockmate-llama-ft)")
    parser.add_argument("--compare-base", nargs="*", default=[], help="Optional additional models to compare (e.g. llama3.2:3b llama3:8b)")
    parser.add_argument("--limit", type=int, default=100, help="Number of test samples to evaluate (default 100)")
    parser.add_argument("--temperature", type=float, default=0.2, help="Sampling temperature")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for sampling and generation")
    parser.add_argument("--run-noise-check", action="store_true", help="Run primary model twice with temp>0 & diff seed to quantify noise X")
    args = parser.parse_args()

    if not TEST_FILE.exists():
        print(f"[ERROR] Test split file missing: {TEST_FILE}")
        sys.exit(1)

    all_lines = [json.loads(l.strip()) for l in TEST_FILE.read_text(encoding="utf-8").splitlines() if l.strip()]
    test_rows = stratified_sample(all_lines, limit=args.limit, seed=args.seed)

    models_to_run = [args.model] + args.compare_base
    results = []

    for m_name in models_to_run:
        if check_ollama_model(m_name):
            res = evaluate_model_on_rows(m_name, test_rows, temperature=args.temperature, seed=args.seed)
            results.append(res)
        else:
            print(f"\n[SKIP] Model '{m_name}' is currently unavailable in local Ollama storage.")

    if len(results) > 1:
        print_side_by_side_multi(results)

    if args.run_noise_check and results:
        diff_seed = args.seed + 1000
        diff_temp = max(0.3, args.temperature)
        print(f"\n--- RUNNING NOISE VARIANCE CHECK (RE-RUNNING '{args.model}' WITH temp={diff_temp}, seed={diff_seed}) ---")
        run2_res = evaluate_model_on_rows(args.model, test_rows, temperature=diff_temp, seed=diff_seed)
        r1_acc = results[0].get("evaluate_answer_analysis", {}).get("band_accuracy_pct", 0)
        r2_acc = run2_res.get("evaluate_answer_analysis", {}).get("band_accuracy_pct", 0)
        diff = round(abs(r1_acc - r2_acc), 2)
        print("=======================================================")
        print(f" NOISE VARIANCE CHECK REPORT: {args.model}")
        print("=======================================================")
        print(f"  - Run 1 (temp={args.temperature}, seed={args.seed}) Band Accuracy : {r1_acc}%")
        print(f"  - Run 2 (temp={diff_temp}, seed={diff_seed}) Band Accuracy: {r2_acc}%")
        print(f"  - Absolute Variance (X)                     : {diff}%")
        print("=======================================================\n")


if __name__ == "__main__":
    main()
