import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Award, ChevronRight, Code, Users } from 'lucide-react';
import { Card } from './Card';

export const InterviewCard = ({ interview }) => {
  const isTechnical = interview.type === 'Technical';
  const badgeClass = isTechnical ? 'badge-tech' : 'badge-hr';

  const getScoreColor = (score) => {
    if (score >= 80) return 'var(--success)';
    if (score >= 60) return 'var(--warning)';
    return 'var(--danger)';
  };

  return (
    <Card hover className="interview-card">
      <div className="flex-between">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div className={`interview-icon ${isTechnical ? 'icon-tech' : 'icon-hr'}`}>
            {isTechnical ? <Code size={20} /> : <Users size={20} />}
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
              <span className={`badge ${badgeClass}`}>{interview.type}</span>
              {isTechnical && <span className="badge badge-medium">{interview.subject}</span>}
              <span className={`badge badge-${(interview.difficulty || 'Medium').toLowerCase()}`}>
                {interview.difficulty || 'Medium'}
              </span>
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Calendar size={14} /> {interview.date}
            </div>
          </div>
        </div>

        <div style={{ textAlign: 'right', display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Score</div>
            {typeof interview.score === 'number' ? (
              <div style={{ fontSize: '1.35rem', fontWeight: 700, color: getScoreColor(interview.score) }}>
                {interview.score}%
              </div>
            ) : (
              // Exited before completing: there is no score yet.
              <div style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-muted)' }}>
                {interview.score}
              </div>
            )}
          </div>

          <Link to={`/result/${interview.id}`} className="btn btn-secondary btn-sm">
            View <ChevronRight size={16} />
          </Link>
        </div>
      </div>
    </Card>
  );
};
