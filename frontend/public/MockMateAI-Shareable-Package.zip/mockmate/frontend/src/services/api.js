/**
 * MockMate AI Centralized Frontend API Service
 * Communicates with Node.js Express REST API backend & AI Engine
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:5001/api';

const fetchAPI = async (endpoint, options = {}) => {
  const token = localStorage.getItem('mockmate_token');

  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const requestUrl = `${API_BASE_URL}${endpoint}`;
  let response;
  try {
    response = await fetch(requestUrl, {
      ...options,
      headers,
    });
  } catch (error) {
    console.error(`[API] Network request failed: ${options.method || 'GET'} ${requestUrl}`, error);
    throw new Error(
      `Unable to reach the MockMate backend at ${API_BASE_URL}. Check that the Node/Express service is running and allows this frontend origin. ${error.message || 'Network request failed.'}`
    );
  }

  const data = await response.json();

  if (!response.ok) {
    const errorMsg = data.message || `Request failed with status ${response.status}`;
    const err = new Error(errorMsg);
    // Preserved when the backend graded the answer but a later step (e.g.
    // generating the next question) failed -- see errorMiddleware.js /
    // interviewEngine.processAnswer -- so the caller can still show the
    // score instead of losing it just because the request errored overall.
    if (data.evaluation) err.evaluation = data.evaluation;
    throw err;
  }

  return data;
};

export const apiService = {
  // Auth
  async register(name, email, password, degree, university, targetRole) {
    const data = await fetchAPI('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password, degree, university, targetRole }),
    });
    if (data.token) localStorage.setItem('mockmate_token', data.token);
    return data;
  },

  async login(email, password) {
    const data = await fetchAPI('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    if (data.token) localStorage.setItem('mockmate_token', data.token);
    return data;
  },

  async getMe() {
    return await fetchAPI('/auth/me', { method: 'GET' });
  },

  logout() {
    localStorage.removeItem('mockmate_token');
  },

  // Password reset
  async requestPasswordReset(email) {
    return await fetchAPI('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  async resetPassword(token, password, confirmPassword) {
    return await fetchAPI('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, password, confirmPassword }),
    });
  },

  // Questions & AI Engine
  async getQuestions(type, subject, difficulty) {
    const params = new URLSearchParams();
    if (type) params.append('type', type);
    if (subject) params.append('subject', subject);
    if (difficulty) params.append('difficulty', difficulty);

    const data = await fetchAPI(`/questions?${params.toString()}`, { method: 'GET' });
    return data.questions || [];
  },

  async createInterview(type, subject, difficulty, questionFormat) {
    const data = await fetchAPI('/interviews', {
      method: 'POST',
      body: JSON.stringify({ type, subject, difficulty, questionFormat }),
    });
    return data;
  },

  async getInterviews() {
    const data = await fetchAPI('/interviews', { method: 'GET' });
    return data.interviews || [];
  },

  async getInterviewById(id) {
    const data = await fetchAPI(`/interviews/${id}`, { method: 'GET' });
    return data.interview;
  },

  async submitAnswer(interviewId, answerPayload) {
    return await fetchAPI(`/interviews/${interviewId}/answers`, {
      method: 'POST',
      body: JSON.stringify(answerPayload),
    });
  },

  async completeInterview(interviewId) {
    return await fetchAPI(`/interviews/${interviewId}/complete`, {
      method: 'POST',
    });
  },

  async getResult(interviewId) {
    return await fetchAPI(`/results/${interviewId}`, { method: 'GET' });
  },

  async getQuestionSolution(interviewId) {
    return await fetchAPI(`/interviews/${interviewId}/solution`, { method: 'GET' });
  },
};
