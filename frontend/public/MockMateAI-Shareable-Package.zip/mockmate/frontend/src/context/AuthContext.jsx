import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiService } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Initialize and check JWT on app startup
  useEffect(() => {
    const checkAuthStatus = async () => {
      const token = localStorage.getItem('mockmate_token');
      if (token) {
        try {
          const res = await apiService.getMe();
          if (res.success && res.user) {
            setUser(res.user);
          } else {
            apiService.logout();
            setUser(null);
          }
        } catch (error) {
          console.warn('[Auth] Stored token verification failed:', error.message);
          apiService.logout();
          setUser(null);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    };

    checkAuthStatus();
  }, []);

  const login = async (email, password) => {
    setLoading(true);
    try {
      const res = await apiService.login(email, password);
      if (res.success && res.user) {
        setUser(res.user);
        return { success: true };
      } else {
        return { success: false, message: res.message || 'Login failed' };
      }
    } catch (err) {
      return { success: false, message: err.message || 'Invalid credentials' };
    } finally {
      setLoading(false);
    }
  };

  const register = async (name, email, password, degree, university, targetRole) => {
    setLoading(true);
    try {
      const res = await apiService.register(name, email, password, degree, university, targetRole);
      if (res.success && res.user) {
        setUser(res.user);
        return { success: true };
      } else {
        return { success: false, message: res.message || 'Registration failed' };
      }
    } catch (err) {
      return { success: false, message: err.message || 'Registration failed' };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    apiService.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        loading,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
