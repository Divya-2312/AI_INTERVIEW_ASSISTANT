import React, { useEffect, useState } from 'react';
import { apiService } from '../services/api';
import { InterviewCard } from '../components/InterviewCard';
import { Card } from '../components/Card';
import { Filter, PlayCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../components/Button';

export const History = () => {
  const [interviews, setInterviews] = useState([]);
  const [filterType, setFilterType] = useState('All'); // 'All', 'technical', 'hr'
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadHistory = async () => {
      try {
        const list = await apiService.getInterviews();
        setInterviews(list);
      } catch (err) {
        console.error('Failed to load history from backend', err);
      } finally {
        setLoading(false);
      }
    };
    loadHistory();
  }, []);

  const filtered = interviews.filter(item => {
    if (filterType === 'All') return true;
    return (item.type || '').toLowerCase() === filterType.toLowerCase();
  });

  const formattedList = filtered.map(i => ({
    id: i._id || i.id,
    date: i.createdAt ? new Date(i.createdAt).toISOString().split('T')[0] : 'Today',
    type: (i.type || 'technical').charAt(0).toUpperCase() + (i.type || 'technical').slice(1),
    subject: (i.subject || 'N/A').toUpperCase(),
    difficulty: (i.difficulty || 'medium').charAt(0).toUpperCase() + (i.difficulty || 'medium').slice(1),
    score: typeof i.score === 'number' ? i.score : 'Not yet finished',
    status: i.status === 'completed' ? 'Completed' : 'In Progress'
  }));

  return (
    <div className="history-page container" style={{ paddingTop: '2rem', maxWidth: '1000px' }}>
      <div className="flex-between" style={{ marginBottom: '2rem' }}>
        <div>
          <h2>My Interview History</h2>
          <p className="subtitle">Database records of your past mock interview sessions.</p>
        </div>

        <Link to="/interview/setup">
          <Button icon={PlayCircle}>Start New Interview</Button>
        </Link>
      </div>

      {/* Filter Bar */}
      <div className="filter-bar card flex-between" style={{ padding: '0.75rem 1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-muted)', fontSize: '0.9rem' }}>
          <Filter size={18} /> Filter by Track:
        </div>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {[
            { label: 'All', value: 'All' },
            { label: 'Technical', value: 'technical' },
            { label: 'HR', value: 'hr' }
          ].map(opt => (
            <button
              key={opt.value}
              className={`filter-btn ${filterType === opt.value ? 'active' : ''}`}
              onClick={() => setFilterType(opt.value)}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* History List */}
      {loading ? (
        <Card className="text-center" style={{ padding: '2rem' }}>Loading interview history from database...</Card>
      ) : formattedList.length === 0 ? (
        <Card className="text-center empty-card" style={{ padding: '3rem' }}>
          <p className="subtitle">No interview records found for track filter "{filterType}".</p>
        </Card>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {formattedList.map(item => (
            <InterviewCard key={item.id} interview={item} />
          ))}
        </div>
      )}
    </div>
  );
};
