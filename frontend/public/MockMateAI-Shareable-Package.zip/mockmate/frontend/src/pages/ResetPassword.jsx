import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { KeyRound } from 'lucide-react';
import { apiService } from '../services/api';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { Input } from '../components/Input';

export const ResetPassword = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token') || '';
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');

    if (!token) {
      setError('This reset link is invalid or incomplete.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setSubmitting(true);
    try {
      await apiService.resetPassword(token, password, confirmPassword);
      navigate('/login', { replace: true, state: { passwordReset: true } });
    } catch (requestError) {
      setError(requestError.message || 'Unable to reset the password. Request a new link.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page container flex-center">
      <div className="auth-card-wrapper">
        <Card className="auth-card">
          <div className="auth-header text-center">
            <div className="auth-logo"><KeyRound size={32} /></div>
            <h2>Reset Password</h2>
            <p className="subtitle">Choose a new password for your account.</p>
          </div>

          {error && <div className="alert alert-danger" role="alert">{error}</div>}

          {!token ? (
            <p role="alert">
              This reset link is invalid or incomplete. <Link to="/forgot-password">Request a new link</Link>.
            </p>
          ) : (
            <form onSubmit={handleSubmit}>
              <Input
                label="New Password"
                name="password"
                type="password"
                placeholder="At least 6 characters"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="new-password"
                required
              />
              <Input
                label="Confirm New Password"
                name="confirmPassword"
                type="password"
                placeholder="Re-enter your new password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                autoComplete="new-password"
                required
              />
              <Button type="submit" size="lg" className="btn-full" disabled={submitting} icon={KeyRound}>
                {submitting ? 'Resetting password...' : 'Reset Password'}
              </Button>
            </form>
          )}

          <div className="auth-footer text-center">
            <Link to="/login">Back to login</Link>
          </div>
        </Card>
      </div>
    </div>
  );
};
