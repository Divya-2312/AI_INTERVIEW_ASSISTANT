import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { Bot, UserPlus } from 'lucide-react';

export const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const destination = location.state?.from;
  const returnTo = destination
    ? `${destination.pathname || ''}${destination.search || ''}${destination.hash || ''}`
    : '/dashboard';

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    degree: 'B.Tech Computer Science',
    university: 'Anna University / Tech Campus',
    targetRole: 'Software Development Engineer (SDE)'
  });

  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: '' });
    }
  };

  const validate = () => {
    const errs = {};
    if (!formData.fullName.trim()) {
      errs.fullName = 'Full name is required';
    }

    if (!formData.email.trim()) {
      errs.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errs.email = 'Enter a valid email format';
    }

    if (!formData.password) {
      errs.password = 'Password is required';
    } else if (formData.password.length < 6) {
      errs.password = 'Password must be at least 6 characters';
    }

    if (formData.confirmPassword !== formData.password) {
      errs.confirmPassword = 'Passwords do not match';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    if (!validate()) return;

    setSubmitting(true);
    const result = await register(
      formData.fullName,
      formData.email,
      formData.password,
      formData.degree,
      formData.university,
      formData.targetRole
    );
    setSubmitting(false);

    if (result.success) {
      navigate(returnTo, { replace: true });
    } else {
      setServerError(result.message || 'Registration failed.');
    }
  };

  return (
    <div className="auth-page container flex-center">
      <div className="auth-card-wrapper" style={{ maxWidth: '550px' }}>
        <Card className="auth-card">
          <div className="auth-header text-center">
            <div className="auth-logo"><Bot size={32} /></div>
            <h2>Student Account Registration</h2>
            <p className="subtitle">Enter your academic details and career target to get started.</p>
          </div>

          {serverError && <div className="alert alert-danger">{serverError}</div>}

          <form onSubmit={handleSubmit}>
            <Input
              label="Full Name"
              name="fullName"
              placeholder="e.g. Alex Morgan"
              value={formData.fullName}
              onChange={handleChange}
              error={errors.fullName}
              required
            />

            <Input
              label="Email Address"
              name="email"
              type="email"
              placeholder="e.g. alex.morgan@student.edu"
              value={formData.email}
              onChange={handleChange}
              error={errors.email}
              required
            />

            <div className="grid-2">
              <Input
                label="Password"
                name="password"
                type="password"
                placeholder="Min 6 characters"
                value={formData.password}
                onChange={handleChange}
                error={errors.password}
                required
              />

              <Input
                label="Confirm Password"
                name="confirmPassword"
                type="password"
                placeholder="Re-enter password"
                value={formData.confirmPassword}
                onChange={handleChange}
                error={errors.confirmPassword}
                required
              />
            </div>

            <Input
              label="Degree / Academic Program"
              name="degree"
              placeholder="e.g. B.Tech Computer Science & Engineering"
              value={formData.degree}
              onChange={handleChange}
            />

            <Input
              label="Institution / University"
              name="university"
              placeholder="e.g. Sona College of Technology / Anna University"
              value={formData.university}
              onChange={handleChange}
            />

            <Input
              label="Target Career Role"
              name="targetRole"
              placeholder="e.g. Software Development Engineer (SDE)"
              value={formData.targetRole}
              onChange={handleChange}
            />

            <Button type="submit" size="lg" className="btn-full" disabled={submitting} icon={UserPlus} style={{ marginTop: '1rem' }}>
              {submitting ? 'Creating Profile & Account...' : 'Register Account'}
            </Button>
          </form>

          <div className="auth-footer text-center">
            Already registered? <Link to="/login" state={location.state}>Login here</Link>
          </div>
        </Card>
      </div>
    </div>
  );
};
