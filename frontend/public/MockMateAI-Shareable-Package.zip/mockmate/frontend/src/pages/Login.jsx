import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { Bot, LogIn } from 'lucide-react';

export const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const destination = location.state?.from;
  const returnTo = destination
    ? `${destination.pathname || ''}${destination.search || ''}${destination.hash || ''}`
    : '/dashboard';

  const [formData, setFormData] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: '' });
    }
  };

  const validate = () => {
    const errs = {};
    if (!formData.email.trim()) {
      errs.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errs.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      errs.password = 'Password is required';
    } else if (formData.password.length < 6) {
      errs.password = 'Password must be at least 6 characters';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    if (!validate()) return;

    setSubmitting(true);
    const result = await login(formData.email, formData.password);
    setSubmitting(false);

    if (result.success) {
      navigate(returnTo, { replace: true });
    } else {
      setServerError(result.message || 'Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="auth-page container flex-center">
      <div className="auth-card-wrapper">
        <Card className="auth-card">
          <div className="auth-header text-center">
            <div className="auth-logo"><Bot size={32} /></div>
            <h2>Student Login</h2>
            <p className="subtitle">Welcome back! Access your MockMate AI prep dashboard.</p>
          </div>

          {location.state?.passwordReset && (
            <div role="status" style={{ marginBottom: '1rem', color: 'var(--success)' }}>
              Password reset successfully. Please log in with your new password.
            </div>
          )}

          {serverError && <div className="alert alert-danger">{serverError}</div>}

          <form onSubmit={handleSubmit}>
            <Input
              label="Student Email Address"
              name="email"
              type="email"
              placeholder="e.g. student@example.com"
              value={formData.email}
              onChange={handleChange}
              error={errors.email}
              required
            />

            <Input
              label="Password"
              name="password"
              type="password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              error={errors.password}
              required
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '-0.5rem', marginBottom: '1rem' }}>
              <Link to="/forgot-password">Forgot Password?</Link>
            </div>

            <Button type="submit" size="lg" className="btn-full" disabled={submitting} icon={LogIn}>
              {submitting ? 'Authenticating...' : 'Login to Dashboard'}
            </Button>
          </form>

          <div className="auth-footer text-center">
            Don't have an account? <Link to="/register" state={location.state}>Create a Student Account</Link>
          </div>
        </Card>
      </div>
    </div>
  );
};
