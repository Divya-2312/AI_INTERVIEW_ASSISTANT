import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, KeyRound, Send } from 'lucide-react';
import { apiService } from '../services/api';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { Input } from '../components/Input';

export const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [developmentResetUrl, setDevelopmentResetUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setMessage('');
    setDevelopmentResetUrl('');
    setSubmitting(true);

    try {
      const result = await apiService.requestPasswordReset(email.trim());
      setMessage(result.message || 'If an account with that email exists, password reset instructions are available.');
      if (result.developmentResetToken) {
        setDevelopmentResetUrl(
          `${window.location.origin}/reset-password?token=${encodeURIComponent(result.developmentResetToken)}`
        );
      }
    } catch (requestError) {
      setError(requestError.message || 'Unable to request a password reset right now.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page container flex-center">
      <div className="auth-card-wrapper">
        <Card className="auth-card">
          <div className="auth-header text-center">
            <div className="auth-logo"><KeyRound size={32} /></div>
            <h2>Forgot Password</h2>
            <p className="subtitle">Enter the email address associated with your account.</p>
          </div>

          {error && <div className="alert alert-danger" role="alert">{error}</div>}
          {message && <div role="status" style={{ marginBottom: '1rem' }}>{message}</div>}

          <form onSubmit={handleSubmit}>
            <Input
              label="Email Address"
              name="email"
              type="email"
              placeholder="e.g. student@example.com"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
            <Button type="submit" size="lg" className="btn-full" disabled={submitting} icon={Send}>
              {submitting ? 'Requesting reset...' : 'Send Reset Link'}
            </Button>
          </form>

          {developmentResetUrl && (
            <div role="status" style={{ marginTop: '1rem', overflowWrap: 'anywhere' }}>
              <strong>Development reset link:</strong>{' '}
              <a href={developmentResetUrl}>{developmentResetUrl}</a>
            </div>
          )}

          <div className="auth-footer text-center">
            <Link to="/login"><ArrowLeft size={14} aria-hidden="true" /> Back to login</Link>
          </div>
        </Card>
      </div>
    </div>
  );
};
